import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Camera, Loader2, CheckCircle, AlertCircle, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';

// TypeScript interfaces
interface UserProfile {
  id: string;
  role: 'student' | 'teacher' | 'parent';
  identifier_code: string;
  name?: string;
  subject?: string;
  grade?: string;
  created_at?: string;
  updated_at?: string;
  // These fields might come from other tables or be added client-side
  full_name?: string;
  avatar_url?: string;
  phone?: string;
}

interface FormData {
  full_name: string;
}

interface FormErrors {
  full_name?: string;
  avatar?: string;
}

export default function Profile() {
  const navigate = useNavigate();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [usersViewData, setUsersViewData] = useState<UserProfile | null>(null);
  const [formData, setFormData] = useState<FormData>({
    full_name: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [successMessage, setSuccessMessage] = useState('');
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [hasChanges, setHasChanges] = useState(false);

  // Fetch user profile on component mount
  useEffect(() => {
    void fetchProfile();
  }, []);

  // Reset success message after 3 seconds
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Track form changes
  useEffect(() => {
    if (userProfile) {
      const initialFormData = {
        full_name: userProfile.full_name || '',
      };
      
      const hasFormChanges = 
        formData.full_name !== initialFormData.full_name;
      
      setHasChanges(hasFormChanges || !!avatarFile);
    }
  }, [formData, avatarFile, userProfile]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        navigate('/login', { replace: true });
        return;
      }
      
      let profileData: UserProfile | null = null;
      
      // Try to get data from users_view first
      const { data: viewData, error: viewError } = await supabase
        .from('users_view')
        .select('id, name, role, identifier_code, subject, grade, created_at, updated_at')
        .eq('id', user.id)
        .single();
      
      console.log('users_view data:', viewData);
      console.log('users_view error:', viewError);
      
      // If users_view query fails, fall back to users table
      if (viewError) {
        console.log('Falling back to users table');
        
        const { data: userData, error: userError } = await supabase
          .from('users')
          .select('id, role, identifier_code, name, subject, grade, created_at, updated_at, full_name, avatar_url, phone')
          .eq('id', user.id)
          .single();
        
        console.log('users table data:', userData);
        console.log('users table error:', userError);
        
        if (userError) throw userError;
        
        profileData = userData as UserProfile;
      } else {
        // If users_view query succeeds, get additional profile data
        profileData = viewData as UserProfile;
        
        // Get additional profile data that might be in the users table but not in the view
        const { data: additionalData, error: additionalError } = await supabase
          .from('users')
          .select('full_name, avatar_url, phone')
          .eq('id', user.id)
          .single();
        
        console.log('Additional data:', additionalData);
        console.log('Additional error:', additionalError);
        
        // Only merge if we got additional data without error
        if (!additionalError && additionalData) {
          profileData = {
            ...profileData,
            full_name: additionalData.full_name || profileData.name || '',
            avatar_url: additionalData.avatar_url || undefined,
            phone: additionalData.phone || '',
          };
        } else {
          // Set defaults for missing fields
          profileData = {
            ...profileData,
            full_name: profileData.name || '',
            avatar_url: undefined,
            phone: '',
          };
        }
      }
      
      console.log('Final profile data:', profileData);
      
      if (profileData) {
        setUserProfile(profileData);
        setFormData({
          full_name: profileData.full_name || profileData.name || '',
        });
        
        if (profileData.avatar_url) {
          setAvatarPreview(profileData.avatar_url);
        }
      }
      
      // Set users_view data
      setUsersViewData(profileData);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  // Form validation
  const validateForm = (data: FormData, file?: File): FormErrors => {
    const errors: FormErrors = {};
    
    // Full name validation
    if (!data.full_name.trim()) {
      errors.full_name = 'Full name is required';
    } else if (data.full_name.length > 100) {
      errors.full_name = 'Full name must be less than 100 characters';
    }
    
    // Avatar file validation
    if (file) {
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
      const maxSize = 5 * 1024 * 1024; // 5MB
      
      if (!allowedTypes.includes(file.type)) {
        errors.avatar = 'Please upload a JPG, PNG, or GIF file';
      } else if (file.size > maxSize) {
        errors.avatar = 'File size must be less than 5MB';
      }
    }
    
    return errors;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validate file
      const fileErrors = validateForm(formData, file);
      if (fileErrors.avatar) {
        setErrors(prev => ({ ...prev, avatar: fileErrors.avatar }));
        return;
      }
      
      // Clear previous error
      setErrors(prev => ({ ...prev, avatar: undefined }));
      
      // Set file for upload
      setAvatarFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setAvatarPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const uploadAvatar = async (): Promise<string | null> => {
    if (!avatarFile || !userProfile) return null;
    
    try {
      setIsUploading(true);
      
      // Create a unique file path
      const fileExt = avatarFile.name.split('.').pop();
      const filePath = `avatars/${userProfile.id}-${Date.now()}.${fileExt}`;
      
      // Upload the file with progress tracking
      const { error: uploadError } = await supabase.storage
        .from('profiles')
        .upload(filePath, avatarFile, {
          cacheControl: '3600',
          upsert: true,
          onUploadProgress: (progress) => {
            const percent = (progress.loaded / progress.total) * 100;
            setUploadProgress(Math.round(percent));
          },
        });
      
      if (uploadError) throw uploadError;
      
      // Get the public URL
      const { data } = supabase.storage
        .from('profiles')
        .getPublicUrl(filePath);
      
      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading avatar:', error);
      setErrors(prev => ({ ...prev, avatar: 'Failed to upload image' }));
      return null;
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userProfile) return;
    
    // Validate form
    const validationErrors = validateForm(formData, avatarFile || undefined);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    
    try {
      setSaving(true);
      
      // Upload avatar if changed
      let avatarUrl = userProfile.avatar_url;
      if (avatarFile) {
        const newAvatarUrl = await uploadAvatar();
        if (newAvatarUrl) {
          avatarUrl = newAvatarUrl;
        }
      }
      
      // Update profile
      const { error } = await supabase
        .from('users')
        .update({
          full_name: formData.full_name,
          avatar_url: avatarUrl,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userProfile.id);
      
      if (error) throw error;
      
      // Update local state
      setUserProfile(prev => prev ? {
        ...prev,
        full_name: formData.full_name,
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString(),
      } : null);
      
      // Reset file state
      setAvatarFile(null);
      
      // Show success message
      setSuccessMessage('Profile updated successfully');
      
      // Reset changes flag
      setHasChanges(false);
    } catch (error) {
      console.error('Error updating profile:', error);
      setErrors({ ...errors, full_name: 'Failed to update profile' });
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    // Show confirmation if there are changes
    if (hasChanges) {
      if (!window.confirm('You have unsaved changes. Are you sure you want to discard them?')) {
        return;
      }
    }
    
    // Reset form data to original values
    if (userProfile) {
      setFormData({
        full_name: userProfile.full_name || '',
      });
    }
    
    // Reset avatar preview
    if (userProfile?.avatar_url) {
      setAvatarPreview(userProfile.avatar_url);
    } else {
      setAvatarPreview(null);
    }
    
    // Clear file input
    setAvatarFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    
    // Clear errors
    setErrors({});
    
    // Reset changes flag
    setHasChanges(false);
  };

  const handleBack = () => {
    if (hasChanges) {
      if (window.confirm('You have unsaved changes. Are you sure you want to go back?')) {
        navigate(-1);
      }
    } else {
      navigate(-1);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Loader2 className="w-5 h-5 text-emerald-600 animate-spin" />
          <span className="text-sm text-gray-600">Loading profile...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={handleBack}
            className="mb-4 flex items-center text-sm text-gray-600 hover:text-emerald-600 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back
          </button>
          
          <h1 className="text-2xl font-bold text-gray-900 sm:text-3xl">Profile Settings</h1>
          <p className="mt-1 text-sm text-gray-500">
            Update your personal information and profile picture
          </p>
        </div>
        
        {/* Success message */}
        {successMessage && (
          <div className="mb-6 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center text-emerald-700">
            <CheckCircle className="w-5 h-5 mr-2 flex-shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}
        
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="md:grid md:grid-cols-3">
            {/* Sidebar */}
            <div className="px-4 py-6 bg-gray-50 sm:p-6 md:col-span-1">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Personal Information</h3>
              <p className="mt-1 text-sm text-gray-500">
                This information will be displayed publicly so be careful what you share.
              </p>
              
              <div className="mt-6">
                <div className="flex flex-col items-center">
                  <div className="relative group">
                    <div className="w-32 h-32 rounded-full overflow-hidden bg-gray-100 border-4 border-white shadow-md">
                      {avatarPreview ? (
                        <img 
                          src={avatarPreview} 
                          alt="Profile" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-emerald-50">
                          <User className="w-16 h-16 text-emerald-300" />
                        </div>
                      )}
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                      className="absolute bottom-0 right-0 bg-emerald-600 text-white p-2 rounded-full shadow-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
                      aria-label="Change profile picture"
                    >
                      {isUploading ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Camera className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                  
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleAvatarChange}
                    accept="image/jpeg,image/png,image/gif"
                    className="hidden"
                    aria-label="Upload profile picture"
                  />
                  
                  {errors.avatar && (
                    <p className="mt-2 text-sm text-red-600">{errors.avatar}</p>
                  )}
                  
                  {isUploading && (
                    <div className="mt-2 w-full max-w-xs">
                      <div className="bg-gray-200 rounded-full h-2.5 mt-1">
                        <div 
                          className="bg-emerald-600 h-2.5 rounded-full" 
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      <p className="text-xs text-gray-500 text-center mt-1">
                        Uploading: {uploadProgress}%
                      </p>
                    </div>
                  )}
                  
                  <div className="mt-4 text-center">
                    <p className="text-sm font-medium text-gray-500">
                      {userProfile?.role.charAt(0).toUpperCase() + userProfile?.role.slice(1)}
                    </p>
                    <p className="text-xs text-gray-500">
                      ID: {userProfile?.identifier_code}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Form */}
            <div className="px-4 py-6 sm:p-6 md:col-span-2">
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label htmlFor="full_name" className="block text-sm font-medium text-gray-700">
                      Full Name
                    </label>
                    <input
                      type="text"
                      name="full_name"
                      id="full_name"
                      value={formData.full_name}
                      onChange={handleInputChange}
                      className={`mt-1 block w-full rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm ${
                        errors.full_name ? 'border-red-300' : 'border-gray-300'
                      }`}
                      placeholder="Your full name"
                      maxLength={100}
                    />
                    {errors.full_name && (
                      <p className="mt-1 text-sm text-red-600">{errors.full_name}</p>
                    )}
                  </div>
                  
                  {/* User Table Data Display */}
                  <div className="mt-8 border-t pt-6">
                    <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">
                      User Database Information
                      <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                        Authenticated User
                      </span>
                    </h3>
                    <p className="text-sm text-gray-500 mb-4">
                      This information is from the database where id = {userProfile?.id}
                    </p>
                    <div className="bg-gray-50 p-4 rounded-lg shadow-inner">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-gray-500">Name</p>
                          <p className="text-sm text-gray-900">{userProfile?.name || 'Not set'}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Role</p>
                          <p className="text-sm text-gray-900">{userProfile?.role}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Identifier Code</p>
                          <p className="text-sm text-gray-900">{userProfile?.identifier_code}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Subject</p>
                          <p className="text-sm text-gray-900">{userProfile?.subject || 'Not applicable'}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Grade</p>
                          <p className="text-sm text-gray-900">{userProfile?.grade || 'Not applicable'}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Created At</p>
                          <p className="text-sm text-gray-900">
                            {userProfile?.created_at ? new Date(userProfile.created_at).toLocaleString() : 'Unknown'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Last Updated</p>
                          <p className="text-sm text-gray-900">
                            {userProfile?.updated_at ? new Date(userProfile.updated_at).toLocaleString() : 'Unknown'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">User ID</p>
                          <p className="text-sm text-gray-900 truncate">{userProfile?.id}</p>
                        </div>
                      </div>
                    </div>
                    
                    {userProfile?.updated_at && (
                      <div className="text-xs text-gray-500 mt-4">
                        Last updated: {new Date(userProfile.updated_at).toLocaleString()}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="mt-8 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving || !hasChanges}
                    className={`py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 ${
                      saving || !hasChanges
                        ? 'bg-emerald-400 cursor-not-allowed'
                        : 'bg-emerald-600 hover:bg-emerald-700'
                    }`}
                  >
                    {saving ? (
                      <span className="flex items-center">
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </span>
                    ) : (
                      'Save Changes'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
